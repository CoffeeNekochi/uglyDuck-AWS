# import json
# import boto3
# def lambda_handler(event, context):
#     client = boto3.client('dynamodb')
#     response = client.put_item(
#         TableName = 'food_list_test',
#         Item = {
#             'food_id'   : {'N':event['food_id']},
#             'datetime'  : {'S':event['datetime']},
#             'tem'       : {'N':event['tem']}
#         }
#     )
#     if int(event['tem']) > 45:
#         client = boto3.client('sns')
#         response = client.publish(
#             TopicArn='arn:aws:sns:us-east-2:647407439568:dynamoDB-SNS-test',
#             Message="Tem is " + str(event['tem']) + " at " + str(event['datetime']),
#             Subject='Tem over 45'
#         )
    
#     return 0