import json
import boto3
import datetime
import time
import dateutil.tz

datetime_dt = datetime.datetime.today()# 獲得當地時間

tw = dateutil.tz.gettz('Asia/Taipei')
utc_dt_now = datetime.datetime.now(tz=tw)
datetime_str = utc_dt_now.strftime("%Y-%m-%d %H:%M")  # 格式化日期
formatted_date_now = time.strptime(datetime_str, "%Y-%m-%d %H:%M")

def scan_datas(display_movies, dynamodb=None): # 取得資料庫所有項目
    if not dynamodb:
        dynamodb = boto3.resource('dynamodb')

    table = dynamodb.Table('food_list')
    scan_kwargs = {}
    response = table.scan(**scan_kwargs)    # scan()
    display_movies(response.get('Items', []))   # 對項目單位進行操作

def lambda_handler(event, context):
    def check_item(items):  #檢查項目是否符合條件
        global datetime_str
        
        for item in items:      # loop 項目
            formatted_date_item = time.strptime(item['exp_date'], "%Y-%m-%d %H:%M")
            if formatted_date_item < formatted_date_now:    # 項目符合條件，觸發SNS發信
                client = boto3.client('sns')    # 載入被觸發對象
                response = client.publish(      # SNS發信內容
                    TopicArn='arn:aws:sns:us-east-2:647407439568:dynamoDB-SNS-test',
                    Subject= "商品 " + str(item['food_id']) + " 已過期，請立即丟棄",
                    Message=    "注意！中央廚房 " + str(item['kitchen_id']) + " 的商品 " + str(item['food_id']) + " " + str(item['food_name']) + 
                                " 已經于 " + str(item['exp_date'] + "過期！ 請立即丟棄！")
                )
    
    # 程式開始
    scan_datas(check_item) #載入資料庫比對觸發條件
    
    return 0
